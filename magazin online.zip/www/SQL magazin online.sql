-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.10-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for magazin_online
CREATE DATABASE IF NOT EXISTS `magazin_online` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `magazin_online`;

-- Dumping structure for table magazin_online.admini
CREATE TABLE IF NOT EXISTS `admini` (
  `admin_username` varchar(100) DEFAULT NULL,
  `admin_password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table magazin_online.admini: ~1 rows (approximately)
/*!40000 ALTER TABLE `admini` DISABLE KEYS */;
INSERT INTO `admini` (`admin_username`, `admin_password`) VALUES
	('alex', 'stefan04');
/*!40000 ALTER TABLE `admini` ENABLE KEYS */;

-- Dumping structure for table magazin_online.categorii
CREATE TABLE IF NOT EXISTS `categorii` (
  `id_categ` int(11) NOT NULL AUTO_INCREMENT,
  `nume_categ` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_categ`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table magazin_online.categorii: ~13 rows (approximately)
/*!40000 ALTER TABLE `categorii` DISABLE KEYS */;
INSERT INTO `categorii` (`id_categ`, `nume_categ`) VALUES
	(1, 'Accesorii auto'),
	(2, 'Chimicale auto'),
	(3, 'Scule si echipamente'),
	(4, 'Becuri'),
	(5, 'Ulei de motor'),
	(6, 'Discuri frana'),
	(7, 'Placute frana'),
	(8, 'Anvelope'),
	(9, 'Filtre'),
	(10, 'Suspensie'),
	(11, 'Caroserie'),
	(12, 'Motor'),
	(13, 'Amortizare');
/*!40000 ALTER TABLE `categorii` ENABLE KEYS */;

-- Dumping structure for table magazin_online.cos_temporar
CREATE TABLE IF NOT EXISTS `cos_temporar` (
  `id_comanda` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_produs` int(11) DEFAULT NULL,
  `cantitate` varchar(100) DEFAULT NULL,
  `data_comanda` date DEFAULT NULL,
  PRIMARY KEY (`id_comanda`),
  KEY `id_user` (`id_user`),
  KEY `id_produs` (`id_produs`),
  CONSTRAINT `cos_temporar_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `useri` (`id_user`),
  CONSTRAINT `cos_temporar_ibfk_2` FOREIGN KEY (`id_produs`) REFERENCES `produse` (`id_produs`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table magazin_online.cos_temporar: ~7 rows (approximately)
/*!40000 ALTER TABLE `cos_temporar` DISABLE KEYS */;
INSERT INTO `cos_temporar` (`id_comanda`, `id_user`, `id_produs`, `cantitate`, `data_comanda`) VALUES
	(11, 3, 11, '1', '2020-05-26'),
	(12, 3, 6, '1', '2020-05-26'),
	(13, 3, 81, '1', '2020-05-26'),
	(14, 3, 85, '1', '2020-05-26'),
	(15, 3, 82, '1', '2020-05-26'),
	(16, 3, 86, '1', '2020-05-26'),
	(17, 3, 97, '1', '2020-05-26'),
	(18, 1, 2, '1', '2020-05-26'),
	(19, 1, 22, '1', '2020-05-26');
/*!40000 ALTER TABLE `cos_temporar` ENABLE KEYS */;

-- Dumping structure for table magazin_online.istoric_comenzi
CREATE TABLE IF NOT EXISTS `istoric_comenzi` (
  `id_comanda` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_produs` int(11) DEFAULT NULL,
  `cantitate` varchar(100) DEFAULT NULL,
  `data_comanda` date DEFAULT NULL,
  PRIMARY KEY (`id_comanda`),
  KEY `id_user` (`id_user`),
  KEY `id_produs` (`id_produs`),
  CONSTRAINT `istoric_comenzi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `useri` (`id_user`),
  CONSTRAINT `istoric_comenzi_ibfk_2` FOREIGN KEY (`id_produs`) REFERENCES `produse` (`id_produs`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table magazin_online.istoric_comenzi: ~10 rows (approximately)
/*!40000 ALTER TABLE `istoric_comenzi` DISABLE KEYS */;
INSERT INTO `istoric_comenzi` (`id_comanda`, `id_user`, `id_produs`, `cantitate`, `data_comanda`) VALUES
	(1, 1, 61, '1', '2020-05-26'),
	(2, 1, 62, '1', '2020-05-26'),
	(3, 1, 83, '1', '2020-05-26'),
	(4, 1, 114, '2', '2020-05-26'),
	(5, 2, 35, '1', '2020-05-26'),
	(6, 2, 34, '2', '2020-05-26'),
	(7, 2, 101, '2', '2020-05-26'),
	(8, 2, 71, '4', '2020-05-26'),
	(9, 2, 25, '1', '2020-05-26'),
	(10, 2, 24, '4', '2020-05-26');
/*!40000 ALTER TABLE `istoric_comenzi` ENABLE KEYS */;

-- Dumping structure for table magazin_online.produse
CREATE TABLE IF NOT EXISTS `produse` (
  `id_produs` int(11) NOT NULL AUTO_INCREMENT,
  `nume_produs` varchar(100) DEFAULT NULL,
  `descriere` varchar(100) DEFAULT NULL,
  `pret_ron` double DEFAULT NULL,
  `id_categ` int(11) DEFAULT NULL,
  `oferta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_produs`),
  KEY `id_categ` (`id_categ`),
  CONSTRAINT `produse_ibfk_1` FOREIGN KEY (`id_categ`) REFERENCES `categorii` (`id_categ`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=latin1;

-- Dumping data for table magazin_online.produse: ~120 rows (approximately)
/*!40000 ALTER TABLE `produse` DISABLE KEYS */;
INSERT INTO `produse` (`id_produs`, `nume_produs`, `descriere`, `pret_ron`, `id_categ`, `oferta`) VALUES
	(1, 'Set de covorase de podea', 'N/A', 65.69, 1, 0),
	(2, 'Senzor de parcare', 'N/A', 60.33, 1, 1),
	(3, 'Suport telefon', 'N/A', 41.97, 1, 0),
	(4, 'Incarcator telefon', 'N/A', 42.99, 1, 0),
	(5, 'Camera auto', 'N/A', 195.91, 1, 1),
	(6, 'GPS', 'N/A', 331.4, 1, 0),
	(7, 'Casca bluetooth', 'N/A', 88.3, 1, 1),
	(8, 'Aspirator de mana', 'N/A', 56.68, 1, 1),
	(9, 'Camera marsarier', 'N/A', 126.12, 1, 0),
	(10, 'Invertor', 'N/A', 181.39, 1, 1),
	(11, 'Pasta pentru slefuirea supapelor', 'N/A', 33.13, 2, 0),
	(12, 'Lichid pentru pornirea rapida a motorului', 'N/A', 130.63, 2, 0),
	(13, 'Aditivi pentru combustibil', 'N/A', 15.2, 2, 0),
	(14, 'Tratament rugina', 'N/A', 13.92, 2, 1),
	(15, 'Substanta curatire instalatie climatizare', 'N/A', 116.26, 2, 0),
	(16, 'Adeziv imbinare elemente caroseriei', 'N/A', 17.07, 2, 0),
	(17, 'Solutie de curatat vopsea', 'N/A', 76.48, 2, 0),
	(18, 'Vopsea pentru detectarea scurgerilor', 'N/A', 23.7, 2, 0),
	(19, 'Spray tehnic', 'N/A', 47.58, 2, 0),
	(20, 'Izolator electric lichid', 'N/A', 9.84, 2, 0),
	(21, 'Pistol de nituit', 'N/A', 58.72, 3, 1),
	(22, 'Cheie dinamometrica', 'N/A', 159.36, 3, 0),
	(23, 'Bormasina de insurubat', 'N/A', 203.64, 3, 1),
	(24, 'Capra auto', 'N/A', 83.79, 3, 0),
	(25, 'Extractor rulmenti', 'N/A', 416.57, 3, 0),
	(26, 'Pistol de insurubat', 'N/A', 308.11, 3, 1),
	(27, 'Filiera', 'N/A', 27.52, 3, 0),
	(28, 'Perie de sarma', 'N/A', 11.12, 3, 1),
	(29, 'Perie pentru curatare', 'N/A', 9.67, 3, 0),
	(30, 'Trusa de scule', 'N/A', 19.02, 3, 1),
	(31, 'Sortimente becuri', 'N/A', 30.67, 4, 1),
	(32, 'Bec semnalizator', 'N/A', 2.02, 4, 0),
	(33, 'Bec iluminare numar inmatriculare', 'N/A', 1.29, 4, 0),
	(34, 'Bec far faza lunga', 'N/A', 83.11, 4, 0),
	(35, 'Bec lampa mers inapoi', 'N/A', 2.7, 4, 1),
	(36, 'Bec lumina stationare', 'N/A', 81.92, 4, 1),
	(37, 'Bec faza scurta', 'N/A', 35.43, 4, 0),
	(38, 'Bec semnalizator galben', 'N/A', 5.93, 4, 1),
	(39, 'Bec lampa frana', 'N/A', 20.64, 4, 1),
	(40, 'Bec lampa ceata', 'N/A', 4.23, 4, 0),
	(41, 'Opel GM Ulei de motor 10W-40, 5 Litri', 'N/A', 94.67, 5, 1),
	(42, 'Opel GM Ulei de motor 5W-30, 5 Litri', 'N/A', 138.87, 5, 0),
	(43, 'Total 5W-30, 5 Litri', 'N/A', 184.86, 5, 1),
	(44, 'K2 Texar 5W-30, 1 Litru', 'N/A', 29.73, 5, 1),
	(45, 'ELF 5W-30, 5 Litri', 'N/A', 203.98, 5, 1),
	(46, 'Castrol Turbo Diesel 5W-40, 5 Litri', 'N/A', 236.54, 5, 0),
	(47, 'Castrol Magnatec, DPF, 5W-40, 5 Litri', 'N/A', 215.12, 5, 0),
	(48, 'Ravenol 5W-30, 5 Litri', 'N/A', 195.06, 5, 1),
	(49, 'Valvoline SynPower 5W-30, 4 Litri', 'N/A', 167.01, 5, 1),
	(50, 'Motul 8100 X-CLEAN+ 5W-30, 5 Litri', 'N/A', 258.98, 5, 0),
	(51, 'Brembo disc frana', 'N/A', 381.29, 6, 0),
	(52, 'ATE disc frana', 'N/A', 246.31, 6, 0),
	(53, 'RIDEX disc frana', 'N/A', 48.94, 6, 0),
	(54, 'TRW disc frana', 'N/A', 95.64, 6, 0),
	(55, 'ZIMMERMANN disc frana', 'N/A', 208.32, 6, 0),
	(56, 'BOSCH disc frana', 'N/A', 137.6, 6, 1),
	(57, 'VALEO disc frana', 'N/A', 164.29, 6, 0),
	(58, 'FERODO disc frana', 'N/A', 375.68, 6, 0),
	(59, 'TEXTAR disc frana', 'N/A', 181.88, 6, 0),
	(60, 'ABS disc frana', 'N/A', 183.33, 6, 1),
	(61, 'ATE placute frana', 'N/A', 267.9, 7, 1),
	(62, 'TRW COTEC placute frana', 'N/A', 142.95, 7, 1),
	(63, 'BREMBO placute frana', 'N/A', 142.87, 7, 0),
	(64, 'RIDEX placute frana', 'N/A', 61.1, 7, 1),
	(65, 'BOSCH placute frana', 'N/A', 106.4, 7, 0),
	(66, 'TEXTAR placute frana', 'N/A', 101.9, 7, 1),
	(67, 'DELPHI placute frana', 'N/A', 128.33, 7, 0),
	(68, 'FERODO placute frana', 'N/A', 142.95, 7, 1),
	(69, 'VALEO placute frana', 'N/A', 94.5, 7, 1),
	(70, 'ZIMMERMANN placute frana', 'N/A', 116.18, 7, 0),
	(71, 'NOKIAN ILINE', 'N/A', 182.48, 8, 1),
	(72, 'PIRELLI CINTURATO', 'N/A', 224.38, 8, 1),
	(73, 'GOODYEAR Eficient Grip', 'N/A', 209.78, 8, 1),
	(74, 'BRIDGESTONE BLIZZAK', 'N/A', 222.58, 8, 0),
	(75, 'CONTINENTAL CONTIECOCONTACT 5', 'N/A', 231.48, 8, 1),
	(76, 'MICHELIN ENERGY SAVER+', 'N/A', 257.88, 8, 0),
	(77, 'DUNLOP STREETRESPONSE 2', 'N/A', 203.58, 8, 1),
	(78, 'FIRESTONE', 'N/A', 190.08, 8, 0),
	(79, 'KLEBER KRISALP', 'N/A', 179.48, 8, 0),
	(80, 'VREDESTEIN QUATRAC 5', 'N/A', 201.88, 8, 0),
	(81, 'MANN Filtru combustibil', 'N/A', 83.98, 9, 0),
	(82, 'PURFLUX Filtru ulei', 'N/A', 24.14, 9, 0),
	(83, 'UFI Filtru ulei', 'N/A', 22.94, 9, 0),
	(84, 'MANN Filtru ulei', 'N/A', 42.62, 9, 1),
	(85, 'MANN Filtru aer', 'N/A', 61.98, 9, 0),
	(86, 'MANN filtru polen', 'N/A', 67.66, 9, 1),
	(87, 'K&N Filtru aer', 'N/A', 260.22, 9, 1),
	(88, 'MEAT&DORIA Filtru ulei insurubabil', 'N/A', 19.5, 9, 0),
	(89, 'BOSCH Filtru combustibil', 'N/A', 104.54, 9, 1),
	(90, 'MAHLE Filtru combustibil', 'N/A', 122.7, 9, 1),
	(91, 'Brat / bieleta suspensie', 'N/A', 113.74, 10, 1),
	(92, 'Set rulment roata', 'N/A', 399.74, 10, 0),
	(93, 'Brat suspensie roata', 'N/A', 304.62, 10, 1),
	(94, 'Cuzinet stabilizator', 'N/A', 21.58, 10, 1),
	(95, 'DIEDERICHS suport bara protectie', 'N/A', 80.38, 10, 0),
	(96, 'Surub clema articulatie', 'N/A', 68.14, 10, 1),
	(97, 'DELPHI set raparatie bara stabilizatoare', 'N/A', 1143.5, 10, 0),
	(98, 'DELPHI bara stabilizatoare', 'N/A', 173.58, 10, 0),
	(99, 'DELPHI Suport trapez', 'N/A', 33.74, 10, 1),
	(100, 'Ridex articulatie directie', 'N/A', 437.66, 10, 0),
	(101, 'Lampa spate', 'N/A', 880.54, 11, 1),
	(102, 'Balama capota motor', 'N/A', 48.3, 11, 1),
	(103, 'Acoperire oglinda exterioara dreapta', 'N/A', 137.82, 11, 0),
	(104, 'JP GROUP Ghidaj cu role', 'N/A', 94.7, 11, 1),
	(105, 'Sticla oglinda retrovizoare stanga', 'N/A', 155.42, 11, 0),
	(106, 'Carenaj pasaj roata stanga fata', 'N/A', 48.62, 11, 0),
	(107, 'Maner usa fata stanga', 'N/A', 81.42, 11, 0),
	(108, 'Suport aripa', 'N/A', 134.54, 11, 0),
	(109, 'HELLA lentila far', 'N/A', 109.18, 11, 0),
	(110, 'Amortizor portbagaj', 'N/A', 47.02, 11, 0),
	(111, 'Surub de golire baie de ulei', 'N/A', 5.98, 12, 0),
	(112, 'GOETZE Set segmenti pisotn', 'N/A', 81.66, 12, 1),
	(113, 'ENGINETEAM Chiulasa', 'N/A', 3134.3, 12, 1),
	(114, 'Suport motor', 'N/A', 80.83, 12, 0),
	(115, 'Baie de ulei', 'N/A', 159.1, 12, 1),
	(116, 'Piston', 'N/A', 460.86, 12, 0),
	(117, 'MAGNETI MARELLI Modul conducta admisie', 'N/A', 1064.86, 12, 1),
	(118, 'IPSA arbore cotit', 'N/A', 2446.38, 12, 0),
	(119, 'Febi bilstein capac distributie', 'N/A', 10.22, 12, 1),
	(120, 'Capac culbutori', 'N/A', 738.46, 12, 0);
/*!40000 ALTER TABLE `produse` ENABLE KEYS */;

-- Dumping structure for table magazin_online.useri
CREATE TABLE IF NOT EXISTS `useri` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `nume` varchar(100) DEFAULT NULL,
  `prenume` varchar(100) DEFAULT NULL,
  `adresa` varchar(100) DEFAULT NULL,
  `telefon` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `localitate` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table magazin_online.useri: ~4 rows (approximately)
/*!40000 ALTER TABLE `useri` DISABLE KEYS */;
INSERT INTO `useri` (`id_user`, `username`, `nume`, `prenume`, `adresa`, `telefon`, `email`, `localitate`, `password`) VALUES
	(1, 'maria1', 'Burlan', 'Maria', 'Str Moinesti nr 2, Scara 2, parter', '0721420657', 'maria.burlan@example.com', 'Bucuresti', 'renata'),
	(2, 'popelea_84', 'Popelea', 'Dan', 'Str Masina de Paine, ap 11', '0721420657', 'dan.popelea@example.com', 'Bucuresti', 'danut'),
	(3, 'mirceav', 'Vasile', 'Mircea', 'Str Mosilor 85', '0721420657', 'vasile.mircea@example.com', 'Bucuresti', 'ltms'),
	(4, 'alex_ion', 'Ion', 'Alexandru', 'Sos Mihai Bravu 188, Bl 211, Sc A', '0721420657', 'ion.sorinalexandru@yahoo.com', '&lt;Bucuresti&gt;', 'alex28');
/*!40000 ALTER TABLE `useri` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
