<?php

namespace Controllers;

class User_modificare1 extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->user_modificare();
		
	}
	
	private function user_modificare() {
		
		$model_obj = new \Models\User_modificare1($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_useri = $model_obj->user_modificare1($this->db_obj);
		
		$view_obj = new \Views\User_modificare1($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_useri);	
		$view_obj->final_output();
		
	}
}