<?php

namespace Controllers;

class Introducere_in_cos extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->input = array(
			'id_produs' => $_REQUEST['id_produs'],//nu este input uman, sunt hidden in formularul din views/detalii_produs
			'nume_produs' => $_REQUEST['nume_produs'],//nu este input uman, sunt hidden in formularul din views/detalii_produs
			'cantitate' => htmlspecialchars(trim($_REQUEST['cantitate'])));
		$this->introducere_in_cos();
		
	}
	
	private function introducere_in_cos() {
		
		$model_obj = new \Models\Introducere_in_cos($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_introducere_in_cos = $model_obj->introducere_in_cos($this->db_obj,$this->input);
		
		
		$view_obj = new \Views\Introducere_in_cos($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute,$results_introducere_in_cos);	
		$view_obj->final_output();
		
	}
}