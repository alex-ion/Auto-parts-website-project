<?php

namespace Controllers;

class Detalii_produs extends Index{
	
	private $db_obj;
	
	public function __construct($id_produs) {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->id_produs = $id_produs;//nu este input uman, deci nu trebuie aplicat htmlspecialchars() si trim()
		$this->produs();
		
	}
	
	private function produs() {
		
		$model_obj = new \Models\Detalii_produs($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_produse1 = $model_obj->produs($this->db_obj,$this->id_produs);
		$results_produse2 = $model_obj->produs($this->db_obj,$this->id_produs);//am creat practic acelasi obiect de 2 ori, pentru ca in Views aveam nevoie atat de obiectul in sine pe care il transmiteam pentru afisarea produsului, dar si de caracteristicile produsului pe care trebuia sa le includ in formular.
		
		$view_obj = new \Views\Detalii_produs($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_produse1, $results_produse2);		
		$view_obj->final_output();
		
	}
}