<?php

namespace Controllers;

class User_modificare2 extends Index{
	
	private $db_obj;
	
	public function __construct() {
		

		$this->db_obj = \Helpers\Database::db_connect();
		$this->parametrii = array(
        'parola' => htmlspecialchars(trim($_REQUEST['txtParola'])),
        'nume' => htmlspecialchars(trim($_REQUEST['txtNume'])),
        'prenume' => htmlspecialchars(trim($_REQUEST['txtPrenume'])),
        'adresa' => htmlspecialchars(trim($_REQUEST['txtAdresa'])),
        'telefon' => htmlspecialchars(trim($_REQUEST['txtTelefon'])),
        'email' => filter_var ($_REQUEST['txtEmail'], FILTER_SANITIZE_EMAIL),
				'localitate' => htmlspecialchars(trim($_REQUEST['txtLocalitate'])));
				
		$this->user_modificare();
	}
	
	private function user_modificare() {
		
		$model_obj = new \Models\User_modificare2($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		
		if (filter_var($this->parametrii['email'], FILTER_VALIDATE_EMAIL) !== false)
		{
			$user_modificare= $model_obj->user_modificare2($this->db_obj,$this->parametrii);
		}
		else
			$user_modificare = "Adresa de e-mail specificata nu are formatul corect";


		$view_obj = new \Views\User_modificare2($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $user_modificare);	
		$view_obj->final_output();
		
	}
}