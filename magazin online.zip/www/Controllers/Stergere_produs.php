<?php

namespace Controllers;

class Stergere_produs extends Index{
	
	private $db_obj;
	
	public function __construct($id_comanda) {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->id_comanda = $id_comanda;
		$this->stergere_produs();
		
	}
	
	public function stergere_produs() {
		
		$model_obj = new \Models\Stergere_produs($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_stergere_produs = $model_obj->stergere_produs($this->db_obj,$this->id_comanda);
		
		$view_obj = new \Views\Stergere_produs($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_stergere_produs);	
		$view_obj->final_output();
		
	}
}