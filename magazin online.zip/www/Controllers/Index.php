<?php

namespace Controllers;

class Index {
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->index();
		
	}
	
	private function index() {
		
		$model_obj = new \Models\Index($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		
		$view_obj = new \Views\Index($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute);	
		$view_obj->final_output();
	
	}
}