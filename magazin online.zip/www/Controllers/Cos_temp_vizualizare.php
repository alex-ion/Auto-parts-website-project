<?php

namespace Controllers;

class Cos_temp_vizualizare extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->cos_temp_vizualizare();
		
	}
	
	private function cos_temp_vizualizare() {
		
		$model_obj = new \Models\Cos_temp_vizualizare($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_cos_temp_vizualizare = $model_obj->cos_temp_vizualizare($this->db_obj);
		
		
		$view_obj = new \Views\Cos_temp_vizualizare($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_cos_temp_vizualizare);	
		$view_obj->final_output();
		
	}
}