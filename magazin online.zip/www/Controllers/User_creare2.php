<?php

namespace Controllers;

class User_creare2 extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->input = array(
			'username' => htmlspecialchars(trim($_REQUEST['username'])),
			'parola' => htmlspecialchars(trim($_REQUEST['parola'])),
			'nume' => htmlspecialchars(trim($_REQUEST['nume'])),
			'prenume' => htmlspecialchars(trim($_REQUEST['prenume'])),
			'telefon' => htmlspecialchars(trim($_REQUEST['telefon'])),
			'email' => filter_var ($_REQUEST['email'], FILTER_SANITIZE_EMAIL),
			'adresa' => htmlspecialchars(trim($_REQUEST['adresa'])),
			'localitate' => htmlspecialchars(trim($_REQUEST['localitate']))
		);
		
		$this->user_creare2();
	}
	
	private function user_creare2() {
		
		$model_obj = new \Models\User_creare2($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();

		if (filter_var($this->input['email'], FILTER_VALIDATE_EMAIL) !== false)
		{
			$results_user_creare = $model_obj->user_creare2($this->db_obj,$this->input);
		}
		else
			$results_user_creare = "Adresa de e-mail specificata nu are formatul corect";
		
		$view_obj = new \Views\User_creare2($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_user_creare);
		$view_obj->final_output();
		
	}

	
}