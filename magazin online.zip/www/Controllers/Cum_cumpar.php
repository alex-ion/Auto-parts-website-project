<?php

namespace Controllers;

class Cum_cumpar extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->cum_cumpar();
		
	}
	
	private function cum_cumpar() {
		
		$model_obj = new \Models\Cum_cumpar($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		
		$view_obj = new \Views\Cum_cumpar($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute);	
		$view_obj->final_output();
		
	}
}