<?php

namespace Controllers;

class Istoric_comenzi extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->introducere_in_cos();
		
	}
	
	private function introducere_in_cos() {
		
		$model_obj = new \Models\Istoric_comenzi($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_istoric_comenzi = $model_obj->istoric_comenzi($this->db_obj);
		
		
		$view_obj = new \Views\Istoric_comenzi($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_istoric_comenzi);	
		$view_obj->final_output();
		
	}
}