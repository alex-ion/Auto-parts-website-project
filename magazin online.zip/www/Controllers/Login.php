<?php

namespace Controllers;

class Login extends Index{
	
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->input = array(
			'username' =>	htmlspecialchars(trim($_REQUEST['username'])),
			'password' => htmlspecialchars(trim($_REQUEST['password']))
		);
		$this->login();
		
	}
	
	private function login() {
		
		$model_obj = new \Models\Login($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_cautare_user = $model_obj->cautare_user($this->db_obj, $this->input);

		$view_obj = new \Views\Login($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_cautare_user);	
		$view_obj->final_output();
		
	}
}



