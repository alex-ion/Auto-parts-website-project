<?php

namespace Controllers;

class Dispatcher {
	
	private $input;
	private $db_obj;
	
	public function __construct() {
		
		$this->input = !empty($_REQUEST) ? $_REQUEST : false;
		$this->db_obj = \Helpers\Database::db_connect();
    $this->filter();
		
	}
	
	private function filter() {
		if (isset($_REQUEST['pagina']))
		{
			if ($_REQUEST['pagina'] == "cum_cumpar"){
				$this->cum_cumpar();

			} elseif ($_REQUEST['pagina'] == "cautare1"){
				$this->cautare1();
				
			} elseif ($_REQUEST['pagina'] == "cautare2"){
				$this->cautare2();		
				
			} elseif ($_REQUEST['pagina'] == "contact"){
				$this->contact();				
				
			} elseif ($_REQUEST['pagina'] == "login"){
				$this->login();				
			
			} elseif ($_REQUEST['pagina'] == "user_administrare"){
				$this->user_administrare();		

			} elseif ($_REQUEST['pagina'] == "user_modificare1"){
				$this->user_modificare1();		
				
			} elseif ($_REQUEST['pagina'] == "user_modificare2"){
				$this->user_modificare2();		

			} elseif ($_REQUEST['pagina'] == "categorii"){
				$this->categorii($_REQUEST['categorie']);
				
			} elseif ($_REQUEST['pagina'] == "detalii_produs"){
				$this->detalii_produs($_REQUEST['id_produs']);		

			} elseif ($_REQUEST['pagina'] == "logout"){
				$this->logout();		
			
			} elseif ($_REQUEST['pagina'] == "user_creare1"){
				$this->user_creare1();					
				
			} elseif ($_REQUEST['pagina'] == "user_creare2"){
				$this->user_creare2();

			} elseif ($_REQUEST['pagina'] == "introducere_in_cos"){
				$this->introducere_in_cos();		

			} elseif ($_REQUEST['pagina'] == "istoric_comenzi"){
				$this->istoric_comenzi();	
				
			} elseif ($_REQUEST['pagina'] == "cos_temp_vizualizare"){
				$this->cos_temp_vizualizare();				

			} elseif ($_REQUEST['pagina'] == "stergere_produs"){
				$this->stergere_produs($_REQUEST['id_comanda']);

			} elseif ($_REQUEST['pagina'] == "plasare_comanda"){
				$this->plasare_comanda();

			} elseif ($_REQUEST['pagina'] == "factura_proforma"){
				$this->factura_proforma();			
		}
		} else {
			$this->index();
    }
    
	}

	
	private function index() {
		
    $controller_obj = new \Controllers\Index;
		
	}
	
	private function cum_cumpar() {

		$controller_obj = new \Controllers\Cum_cumpar;

  }
  
  private function cautare1() {

		$controller_obj = new \Controllers\Cautare1;

  }

  private function cautare2() {

		$controller_obj = new \Controllers\Cautare2;

  }

	private function contact() {

		$controller_obj = new \Controllers\Contact;

	}
	
	private function login() {

		$controller_obj = new \Controllers\Login;

  }

		
	private function user_administrare() {

		$controller_obj = new \Controllers\User_administrare;

  }

	private function user_modificare1() {

		$controller_obj = new \Controllers\User_modificare1;

	}
	
	private function user_modificare2() {

		$controller_obj = new \Controllers\User_modificare2;

	}

	private function categorii($categorie) {
		
		$controller_obj = new \Controllers\Categorii($categorie);

	}

	private function detalii_produs($id_produs) {
		
		$controller_obj = new \Controllers\Detalii_produs($id_produs);

	}

	
	private function logout() {

		$controller_obj = new \Controllers\Logout;

	}

	private function user_creare1() {

		$controller_obj = new \Controllers\User_creare1;

	}


	private function user_creare2() {

		$controller_obj = new \Controllers\User_creare2;

	}

	private function introducere_in_cos() {

		$controller_obj = new \Controllers\Introducere_in_cos;

	}
	
	private function istoric_comenzi() {

		$controller_obj = new \Controllers\Istoric_comenzi;

	}
	
	private function cos_temp_vizualizare() {

		$controller_obj = new \Controllers\Cos_temp_vizualizare;

	}	

	private function stergere_produs($id_comanda) {

		$controller_obj = new \Controllers\Stergere_produs($id_comanda);

	}	

	private function plasare_comanda() {

		$controller_obj = new \Controllers\Plasare_comanda;

	}	

	private function factura_proforma() {

		$controller_obj = new \Controllers\Factura_proforma;

	}	
}