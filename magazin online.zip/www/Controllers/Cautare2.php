<?php

namespace Controllers;

class Cautare2 extends Index{
	
	private $parametrii;
	private $db_obj;
	
	public function __construct() {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->parametrii = array(
			'produs_cautat' => htmlspecialchars(trim($_REQUEST['produs_cautat'])),
			'id_categ' => $_REQUEST['id_categ']//preluarea parametrului se face dintr-o lista, deci nu trebuie aplicat htmlspecialchars() si trim()
		);
		$this->cautare();
		
	}
	
	private function cautare() {
		
		$model_obj = new \Models\Cautare2($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_gasire_produs = $model_obj->gasire_produs($this->db_obj, $this->parametrii);

		$view_obj = new \Views\Cautare2($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_gasire_produs, $this->parametrii);
		
		$view_obj->final_output();
		
	}

	
}