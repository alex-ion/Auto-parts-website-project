<?php

namespace Controllers;

class Categorii extends Index{
	
	private $db_obj;
	
	public function __construct($categorie) {
		
		$this->db_obj = \Helpers\Database::db_connect();
		$this->categorie = $categorie;//nu este input uman, deci nu trebuie aplicat htmlspecialchars() si trim()
		$this->categorii();
		
	}
	
	private function categorii() {
		
		$model_obj = new \Models\Categorii($this->db_obj);
		$results_produse_la_promotie = $model_obj->produse_la_promotie();
		$results_sumar_categorii = $model_obj->sumar_categorii();
		$results_cele_mai_vandute = $model_obj->cele_mai_vandute();
		$results_categorii = $model_obj->categorii($this->db_obj,$this->categorie);
		$results_nume_categorie = $model_obj->nume_categorie($this->db_obj,$this->categorie);
		

		$view_obj = new \Views\Categorii($results_produse_la_promotie, $results_sumar_categorii, $results_cele_mai_vandute, $results_categorii, $results_nume_categorie);		
		$view_obj->final_output();
		
	}
}