<?php

namespace Views;

class Login extends Index{
	
  public function __construct($a,$b,$c,$d){

    parent::__construct($a,$b,$c);
    $this->useri = $d;

  }



  private function login(){

    $nr_results = $this->useri->rowCount(); 

    if ($nr_results==0)
      $output = ("<p align='center'>Nu ati introdus datele corect!</p>");
    else
       {
        $output =  ("<p align='center'>Autentificarea s-a facut cu succes!<br></p>");
         while ($row = $this->useri->fetch())
        {
          $_SESSION['id_user'] = $row['id_user']; 
          $_SESSION['userlogat'] = ucwords($row['nume'].' '.$row['prenume']);
          $output .= "<p align='center'><div align='center'><a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare cos cumparaturi</a></p>";
        }
       }

    return $output;

  }


  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->login();
    $output .= $this->right_panel();

    echo $output;

  }

}
