<?php

namespace Views;

class User_modificare1 extends Index{
	
	public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->useri = $d;

  }
 
  private function user_modificare1() {

  
    if ($_SESSION['userlogat'] == "")
      $output = $_SESSION['nelogat'];
    else{

      $nr_results = $this->useri->rowCount(); 
      $output = "<div align='center'>";
      if ($nr_results == 0)
        $output .=  "Nu exista user in baza de date!";
      else
        {
        $output .=  "<form method='POST' action='index.php?pagina=".'user_modificare2'."'>
            <table border='0' bordercolor='#808080' cellpadding='2' cellspacing='0'>";
        while ($row = $this->useri->fetch()){
          $output .= "
            <tr>
              <td>User: </td>
              <td><b>{$_SESSION['userlogat']}</b></td>
            </tr>
            <tr>
              <td>Parola:</td>
              <td><input type='text' name='txtParola' value='{$row['password']}' class='txt'></td>
            </tr>
            <tr>
              <td> Nume:</td>
              <td><input type='text' name='txtNume' value='{$row['nume']}' class='txt'></td>
            </tr>
            <tr>
              <td> Prenume:</td>
              <td><input type='text' name='txtPrenume' value='{$row['prenume']}' class='txt'></td>
            </tr>
            <tr>
                <td>Adresa:</td>
              <td><input type='text' name='txtAdresa' value='{$row['adresa']}' class='txt'></td>
            </tr>
            <tr>
              <td>Telefon:</td>
              <td><input type='text' name='txtTelefon' value='{$row['telefon']}' class='txt'></td>
            </tr>
            <tr>
              <td>E-mail:</td>
              <td><input type='text' name='txtEmail' value='{$row['email']}' class='txt'></td>
            </tr>
            <tr>
              <td>Localitate:</td>
              <td><input type='text' name='txtLocalitate' value='{$row['localitate']}' class='txt'></td>
            </tr>
            <tr>
              <td><input type='submit' name='btn_submit' value='Modificare' class='buton'></td>
            </tr>";
          }
        $output .=  "</table>
            </form>";
        }
      $output .=  "</div>";
    }
  
    return $output;
  }


  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->user_modificare1();
    $output .= $this->right_panel();

    echo $output;

  }

}