<?php

namespace Views;

class Cum_cumpar extends Index{
	 
  private function cum_cumpar() {

    $output = "
      <p>
        Pentru a achizitiona produse de la compania noastra, aveti la dispozitie mai multe modalitati de comanda/achizitie, cat si de plata: <br><br>
        <ol>
          <li>MODALITATI DE COMANDA</b></li><br>
            <ul>
              <li>COMANDA ON-LINE</li>
              <li>COMANDA TELEFONICA la numarul: <b>0721.420.657</b></li>
            </ul><br><br>
          <li>MODALITATI DE PLATA</b></li><br>
            <ul>
              <li>NUMERAR, LA LIVRARE</li>
              <li>OP / VIRAMENT BANCAR (PERS FIZICE SI JURIDICE)</li>
            </ul><br>
              Plata in numerar se face la livrare, in lei, la valoarea din momentul confirmarii telefonice a comenzii. Plata se face catre curierul care efectueaza livrarea <br><br><br>
          <li>LIVRAREA PRODUSELOR</b></li><br>
            <b>Bucuresti</b> (termen de livrare <b>maxim doua zile</b>) <br>
              <ul><li><b>GRATUIT</b> la adresa cumparatorului daca valoarea comenzii depaseste <b>400 RON</b></li>
              <li>TAXA LIVRARE <b>17 RON</b> daca valoarea comezii este <b>sub 400 RON</b></li></ul><br>
            
            <b>Alte localitati</b> (termen de livrare <b>maxim 5 zile</b>) <br>
              <ul><li><b>GRATUIT</b> la adresa cumparatorului daca valoarea comenzii depaseste <b>1100 RON</b></li>
              <li>TAXA LIVRARE <b>20 RON</b> daca valoarea este <b>sub 1100 RON</b> (pentru plati facute prin op/virament bancar)</li>
              <li>TAXA LIVRARE <b>20 RON</b> daca valoarea este <b>sub 1100 RON + TAXA RAMBURS</b> (incasata de firma de curierat)</li>
              <li><b>15 RON</b> (pentru plati facute numerar la livrare)</li>
        </ol>
      </p>";

    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->cum_cumpar();
    $output .= $this->right_panel();

    echo $output;

  }

}