<?php

namespace Views;

class Plasare_comanda extends Index{
  

  public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->rezultat_introducere = $d;

  }

  private function plasare_comanda() {

    if ($this->rezultat_introducere)
      $output = "<p align='center'>Plasarea comenzii a fost efectuata cu succes!</p>";
    else
      $output = "<p align='center'>Eroare la introducerea in baza de date!</p>";
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->plasare_comanda();
    $output .= $this->right_panel();

    echo $output;

  }

}




