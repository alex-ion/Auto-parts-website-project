<?php

namespace Views;


class User_creare2 extends Index{
  
  private $categorii;

	public function __construct($a, $b, $c, $d) {
    
    parent::__construct($a,$b,$c);
    $this->results = $d;

  }

 
  private function user_creare2(){
    
    $output = "<p align='center'>{$this->results}</p>";

    return $output;

  }
  

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->user_creare2();
    $output .= $this->right_panel();

    echo $output;

  }

}