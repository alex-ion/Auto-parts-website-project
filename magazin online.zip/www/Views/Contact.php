<?php

namespace Views;

class Contact extends Index{
	

  private function contact() {

    $output = "<p align='center'>";
    $output .= "<b>{$_SESSION['firma_nume']}</b><br>"; 
    $output .= "Telefon: {$_SESSION['telefon']}<br>";
    $output .= "E-mail: {$_SESSION['email_site']}<br>";
    $output .= "Website: <a href='{$_SESSION['adresa_site']}'> {$_SESSION['adresa_site']}</a><br></p>";
    
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->contact();
    $output .= $this->right_panel();

    echo $output;

  }

}