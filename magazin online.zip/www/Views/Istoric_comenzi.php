<?php

namespace Views;

class Istoric_comenzi extends Index{
  

  public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->istoric_comenzi = $d;

  }

  private function istoric_comenzi() {

  
    $nr_results = $this->istoric_comenzi->rowCount();  
    if ($nr_results == 0)
      $output = "<p align='center'>Nu ati plasat comenzi pana acum!</p>";
    else 
    {
      $output = "<table width='100%' border='1' cellspacing='0' cellpadding='2'  bordercolor='#BBD1E6'>
                  <tr>
                    <td><b>Nume produs</b></td>
                    <td><b>Cantitate</b></td>
                    <td><b>Pret (cu TVA)</b></td>
                    <td><b>Valoare</b></td>
                    <td><b>Data comanda</b></td>
                  </tr>";
  
      $valoare_totala = 0;
      while ($row = $this->istoric_comenzi->fetch())
        {
          $id_comanda = $row['id_comanda'];
          $id_produs = $row['id_produs'];
          $nume_produs = $row['nume_produs'];
          $pret_ron = $row['pret_ron'];
          $cantitate = $row['cantitate'];
          $valoare = $cantitate * $pret_ron;
          $data_comanda = $row['data_comanda'];
  
          $output .= "  <tr>
                          <td><a href='index.php?pagina=detalii_produs&id_produs={$id_produs}'>$nume_produs</a></td>
                          <td>$cantitate</td>
                          <td>$pret_ron</td>
                          <td>$valoare</td>
                          <td>$data_comanda</td>
                        </tr>";
  
          $valoare_totala = $valoare_totala + $valoare;
        }
      $output .= "</table>";
      $output .= "<p align=center>Total fara TVA <b>" . round ($valoare_totala/1.19 , 2) . " RON</b>.</p>";
      $output .= "<p align=center>Total cu TVA <b>" . $valoare_totala . " RON</b>.</p>";
      $output .= "<p align=center><a href='index.php?pagina=factura_proforma'>Generare factura proforma</a></p>";
      $output .= "<p align=center><a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare cos curent</a></p>";
    }

    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->istoric_comenzi();
    $output .= $this->right_panel();

    echo $output;

  }

}


  
