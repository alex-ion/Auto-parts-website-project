<?php

namespace Views;

class Factura_proforma extends Index{
  

  public function __construct($a, $b, $c,$d, $e) {
    
    parent::__construct($a,$b,$c);
    $this->date_user = $d;
    $this->istoric_comenzi = $e;
  }

  private function factura_proforma() {

    $data_curenta = date('Y-m-d');
    $output = "<div align='center'>
      <table width='80%' border='0' cellspacing='0' cellpadding='2'>
        <tr>
        <td width='35%'>
          <b>Furnizor</b>: {$_SESSION['firma_nume']}<br>
          <b>Nr.Reg.Com.</b>: {$_SESSION['firma_nrc']}<br>
          <b>C.U.I.</b>: {$_SESSION['firma_cui']}<br>
          <b>Sediul</b>: {$_SESSION['firma_adresa']}<br>
          <b>Banca</b>: {$_SESSION['firma_banca']}<br>
          <b>Contul</b>: {$_SESSION['firma_cont']}<br>
        </td>
        <td width='30%'>
          <div align = center>
            <h1>
              Factura proforma
            </h1>
            <b>Data</b>: {$data_curenta}<br>
          </div>
        </td>
        <td width='35%'>";
        while ($row = $this->date_user->fetch())
              {
                $nume = $row['nume'];
                $prenume = $row['prenume'];
                $adresa = $row['adresa'];
                $localitate = $row['localitate'];
              
                $output .= "<b>Client</b><br><b>Nume</b>: {$nume}<br>
                            <b>Prenume</b>: {$prenume}<br>
                            <b>Sediul</b>: {$adresa}<br>
                            <b>Localitate</b>: {$localitate}<br>";
              }
    $output .= "</td>
                </tr>
            </table>
          </div>
          <p>&nbsp</p>
          <p>&nbsp</p>";

    $output .= "<div align = center>
                <table width='80%' border='1' cellspacing='0' cellpadding='2'  bordercolor='#BBD1E6'>
                  <tr>
                    <td><b>Nr</b></td>
                    <td><b>Nume produs</b></td>
                    <td><b>Cantitate</b></td>
                    <td><b>Pret fara TVA</b></td>
                    <td><b>Valoare fara TVA</b></td>
                    <td><b>TVA</b></td>
                  </tr>";
      
    $valoare_totala=0;
    $nr_crt=0;
    while ($row = $this->istoric_comenzi->fetch())
          {
          $nr_crt++;
          $id_produs = $row['id_produs'];
          $nume_produs = $row['nume_produs'];
          $pret_ron = $row['pret_ron'];
          $cantitate = $row['cantitate_produs'];
          $valoare = $row['valoare'];
          $data_comanda = $row['data_comanda'];
      
          $pret_fara_tva = $pret_ron / 1.19;
          $valoare_fara_tva = $valoare / 1.19;
          $tva = $valoare_fara_tva * 0.19;

          $output .= "<tr>
                        <td>$nr_crt</td>
                        <td><a href='index.php?pagina=detalii_produs&id_produs={$id_produs}'>$nume_produs</a></td>
                        <td>$cantitate</td>
                        <td>" . round ($pret_fara_tva,2) . "</td>
                        <td>" . round ($valoare_fara_tva,2) . "</td>
                        <td>" . round ($tva,2) . "</td>
                      </tr>";

          $valoare_totala += $valoare;
          }
    $valoare_fara_tva = $valoare_totala/1.19;
      
    $output .= "<tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><b>Totaluri</b></td>
                  <td><b>" . round ($valoare_fara_tva, 2) . " RON</b></td>
                  <td><b>" . round ($valoare_fara_tva*0.19 , 2) . " RON</b></td>
                </tr>
              </table>
            </div>
        <p align=center>Total valoare cu TVA: <b>" . $valoare_totala . " RON</b></p>
        <p align=center>Va rugam sa platiti aceasta factura si sa ne trimiteti confirmarea platii pe email.</p>";
      
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->factura_proforma();
    $output .= $this->right_panel();

    echo $output;

  }

}