<?php

namespace Views;


class Categorii extends Index{
  
  private $categorii;

	public function __construct($a, $b, $c, $d, $e) {
    
    parent::__construct($a,$b,$c);
    $this->produse = $d;
    $this->categorie = $e->fetch();
    $this->categorie = $this->categorie['nume_categ'];
  }

  private function categorii(){

    $nr_results = $this->produse->rowCount();  
    if ($nr_results == 0)
      $output = "<div align='center'>Nu exista produse in categoria <b>{$this->categorie}</b>!</div> <br>";
    else
      {
        $output = "<div align='center'><h1>Produse din categoria {$this->categorie}</h1></div> <br>";
        $output .= Index::tabel_produse($this->produse);
      }

    return $output;
  }



  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->categorii();
    $output .= $this->right_panel();

    echo $output;

  }

}


  

