<?php

namespace Views;

class Stergere_produs extends Index{
	

  public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->results_stergere = $d;

  }


  private function stergere_produs() {

    $nr_results = $this->results_stergere->rowCount();  

    if ($nr_results === 0)
      $output = "Eroare la stergerea din baza de date!";
    else {
      $output = "<p align=center>
                  Stergerea a fost efectuata!<br>
                  <a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare continut cosulet</a>
                </p>";
    }

    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->stergere_produs();
    $output .= $this->right_panel();

    echo $output;

  }

}