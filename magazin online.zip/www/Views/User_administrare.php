<?php

namespace Views;


class User_administrare extends Index{
  
  private $categorii;

	public function __construct($a, $b, $c) {
    
    parent::__construct($a,$b,$c);

  }


  private function user_administrare(){

    if (isset($_SESSION['userlogat']))
    {
      $output = "
          <div align='center'>
            <table border='0' width='400' cellpadding='0'>
              <tr>
                <td width='50%'><a href='index.php?pagina=istoric_comenzi'>Vizualizare istoric comenzi</a></td>
                <td width='50%' align='right'><a href='index.php?pagina=user_modificare1'>Modificare date utilizator</a></td>
              </tr>
              <tr>
                <td width='50%'><a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare cos curent</a></td>
              </tr>
            </table>
          </div>";
    } else {
      $output = "
      <div align='center'>
        <a href='index.php?pagina=user_creare1'>Creare cont utilizator</a>
      </div>";
    }

    return $output;
  }



  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->user_administrare();
    $output .= $this->right_panel();

    echo $output;

  }

}