<?php

namespace Views;


class Cautare1 extends Index{
  
  private $categorii;

	public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->categorii = $d;

  }


  private function cautare1() {

    $output = "<div align='center'>
        <form name='cautare' method='post' action='index.php?pagina=cautare2' >
          <table border='0'>
            <tr>
              <td>Nume produs:&nbsp;</td>
              <td><input type='text' required='true' autofocus='true' name='produs_cautat' class='txt'>&nbsp;</td>
            </tr>";

    $nr_results = $this->categorii->rowCount();    
  
    if ($nr_results == 0)
      $output = "Nu exista date in baza! <br>";
    else
      { 
        $output .= "
        <tr>
          <td width='50%'>
            Categorie:
          </td>
          <td width='50%'>
            <select name='id_categ' class='txt'>
              <option value='all'>*</option>";
        while ($row = $this->categorii->fetch())
          {
            $id_categ = $row['id_categ'];
            $nume_categ = $row['nume_categ'];
            $output .= '<option value="' . $id_categ . '">' . $nume_categ . '</option>';
          }
          $output .= "</select>
                    </td> 
                  </tr>";
        }
    $output .= "<tr>
          <td>&nbsp;</td>
          <td><input type='submit' name='Submit' value='Cauta produs' class='buton'>&nbsp;</td>
        </tr>
      </table>
      </form>
      </div>";
    
      return $output;
  }


  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->cautare1();
    $output .= $this->right_panel();

    echo $output;

  }

}