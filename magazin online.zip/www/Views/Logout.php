<?php

namespace Views;

class Logout extends Index{
	

  private function logout() {
    
    $output = "<p align='center'>La revedere {$_SESSION['userlogat']}, iti multumim pentru vizita!</p>";
    unset($_SESSION['userlogat']);
    unset($_SESSION['id_user']);
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->logout();
    $output .= $this->right_panel();

    echo $output;

  }

}