<?php

namespace Views;

class User_modificare2 extends Index{
	
	public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->rezultat = $d;
    
  }
 
  private function user_modificare2() {
    
    if (gettype($this->rezultat) == 'object')
      $output ="<p align='center'>Modificarea a fost efectuata!</p>";
    else 
      $output = "<p align='center'>{$this->rezultat}</p>";
    return $output;
  }


  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->user_modificare2();
    $output .= $this->right_panel();

    echo $output;

  }

}