<?php

namespace Views;


class Cautare2 extends Index{
  


	public function __construct($a, $b, $c, $d, $e) {
    
    parent::__construct($a,$b,$c);
    $this->produse_gasite = $d;
    $this->parametrii = $e;

  }

 
  private function cautare2(){
    
    $output = '';

      $produs_cautat = $this->parametrii['produs_cautat'];

      if ($produs_cautat != ""){
        $output .= "<div align='center'>Produs cautat: <b>" . $produs_cautat . "</b> <br></div>";
      }



    $nr_results = $this->produse_gasite->rowCount();  

    if ($nr_results === 0)
       $output .= "<div align='center'>Nu au fost identificate produse in baza informatiilor furnizate!</div>";
    else
      {
        $output .= Index::tabel_produse($this->produse_gasite);
        $output .= "<div align='center'>Total produse gasite: <b>" . $nr_results . "</b>. </div>";
      }
    
    return $output;

  }
  

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->cautare2();
    $output .= $this->right_panel();

    echo $output;

  }

}