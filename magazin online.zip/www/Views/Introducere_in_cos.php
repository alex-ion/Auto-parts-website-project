<?php

namespace Views;

class Introducere_in_cos extends Index{
  

  public function __construct($a, $b, $c,$d) {
    
    parent::__construct($a,$b,$c);
    $this->rezultat_introducere = $d;

  }

  private function introducere_in_cos() {

    if (!$this->rezultat_introducere)
      $output = "<p align='center'>Nu ati introdus o valoare corecta pentru cantitate!</p>";
    else
      {
        $nr_results = $this->rezultat_introducere->rowCount();  
        if ($nr_results === 0)
          $output = "Eroare la introducerea in baza de date!";
        else 
        {
          $output = "<div align='center'>";
          $output .= "Produsul a fost introdus in cos!<br><br>";
          $output .= "<a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare continut comenzi temporare</a><br><br>";
          $output .= "<a href='index.php?pagina=istoric_comenzi'>Istoric comenzi</a><br>";
          $output .= "</div>";
        }
      }
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->introducere_in_cos();
    $output .= $this->right_panel();

    echo $output;

  }

}

