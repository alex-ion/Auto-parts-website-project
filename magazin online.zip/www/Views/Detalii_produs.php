<?php

namespace Views;


class Detalii_produs extends Index{
  
  private $categorii;

	public function __construct($a, $b, $c, $d, $e) {
    
    parent::__construct($a,$b,$c);
    $this->id_produs = $d;
    $this->proprietati_produs = $e->fetch();

  }

  private function afisare_produs(){

    $nr_results = $this->id_produs->rowCount();  
    if ($nr_results == 0)
      $output = "<div align='center'>Produsul nu a fost gasit in baza de date!</div> <br>";
    else
      {
        $output = Index::produs($this->id_produs->fetch());
      }

    return $output;
  }


  private function formular_comanda(){

    $output = "<div align=center>";
    if (!isset($_SESSION['userlogat']))
      $output .= $_SESSION['nelogat'];
    else 
      {
        $output .= "<form name='comanda' method='post' action='index.php?pagina=introducere_in_cos'>";
        $output .= "<input type='hidden' name='id_produs' value='" . $this->proprietati_produs['id_produs'] . "'>";
        $output .= "<input type='hidden' name='nume_produs' value='" . $this->proprietati_produs['nume_produs'] . "'>";
        $output .= "Cantitate: <input type='text' name='cantitate' size='1' value='1' class='txt'> bucati<br>";
        $output .= "<input type='submit' name='Submit' value='Adauga in cos' class='buton'>";
        $output .= "</form>";
    }
        $output .= "</div>";
    
    return $output;

  }

  public function final_output(){
    
    $output = $this->left_panel($this->meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->afisare_produs();
    $output .= $this->formular_comanda();
    $output .= $this->right_panel();

    echo $output;

  }

}