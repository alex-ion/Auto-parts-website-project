<?php

namespace Views;

class User_creare1 extends Index{
	

  private function user_creare1() {

    $output = "
      <div align='center'>
        <form name='creare_user' method='post' action='index.php?pagina=user_creare2' onSubmit='return Validare(this);'>
          <table border='0' width='250' cellpadding='0'>
            <tr>
              <td width='50%'>
                <font color='#FF0000'>
                Username:
                </font>
              </td>
              <td width='50%'>
                <input type='text' name='username' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                <font color='#FF0000'>
                Parola:
                </font>
              </td>
              <td width='50%'>
                <input type='password' name='parola' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                Nume:
              </td>
              <td width='50%'>
                <input type='text' name='nume' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                Prenume:
              </td>
              <td width='50%'>
                <input type='text' name='prenume' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                Telefon:
              </td>
              <td width='50%'>
                <input type='text' name='telefon' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                <font color='#FF0000'>
                E-mail:
                </font>
              </td>
              <td width='50%'>
                <input type='text' name='email' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                Adresa:
              </td>
              <td width='50%'>
                <input type='text' name='adresa' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%'>
                Localitate:
              </td>
              <td width='50%'>
                <input type='text' name='localitate' class='txt'>
              </td>
            </tr>
            <tr>
              <td width='50%' align='right'>
                <input type='submit' value='Creare user' name='btn_submit' class='buton'>
              </td>
            </tr>
          </table>
        </form>
      </div>

      <p align='center'>
        <font color='#FF0000'>
          Campurile de culoare rosie sunt obligatorii!
        </font>
      </p>";
    
    return $output;
  }

  public function final_output(){
    
    $output = $this->left_panel(Index::meniu(),Index::sumar_categorii(),Index::cele_mai_vandute());
    $output .= $this->user_creare1();
    $output .= $this->right_panel();

    echo $output;

  }

}

?>

<script language=JavaScript>
function Validare(creare_user)
{
 if (creare_user.username.value=="")
  {
   alert ("Nu ati introdus numele de utilizator!");
   creare_user.username.focus();
   return false;
  }
 if (creare_user.parola.value=="")
  {
   alert ("Nu ati introdus parola!");
   creare_user.parola.focus();
   return false;
  }
 if (creare_user.email.value=="")
  {
   alert ("Nu ati introdus adresa de e-mail!");
   creare_user.email.focus();
   return false;
  }
    
  return true;

}
</script>