<?php

namespace Views;

class Index {
  
  private $results_produse_la_promotie;
  private $results_sumar_categorii;
	private $results_cele_mai_vandute;
  
  
	public function __construct($a, $b, $c) {
		
		$this->results_produse_la_promotie = $a;
		$this->results_sumar_categorii = $b;
    $this->results_cele_mai_vandute = $c;
    
  }
  

  protected function sumar_categorii() {

    $output = "<table border=1 width='100%' cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
    <tr>
      <td>";
    $nr_results = $this->results_sumar_categorii->rowCount();
    
    if ($nr_results != 0)
    {
      $output .= '<div align=center><h3>Categorii</h3></div>';
       while ($row = $this->results_sumar_categorii->fetch()){
         $id_categ = $row['id_categ'];
         $nume_categ = $row['nume_categ'];
         $output .= "<li> <a href='index.php?pagina=categorii&categorie={$id_categ}'>" . $nume_categ . "</a><br>";
       }
     }
  
     $output .= "</td>
               </tr>
             </table>";
  
  return $output;
  
  }	


  protected function cele_mai_vandute() {
    $output = "<table border=1 width='100%' cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
        <tr>
          <td>";
    $nr_results = $this->results_cele_mai_vandute->rowCount();

    if ($nr_results != 0)
      {
        $output .= '<div align=center><h3>Cele mai bine vandute 10 produse</h3></div><br>';
        while ($row = $this->results_cele_mai_vandute->fetch()){
            $id_produs = $row['id_produs'];
            $nume_produs = $row['nume_produs'];
            $output .= "<li> <a href='index.php?pagina=detalii_produs&id_produs=" . $id_produs . "'>" . ucfirst($nume_produs) . "</a><br>";
          }
      }

      $output .= "</td>
              </tr>
          </table>";

      return $output;
  }


	protected function left_panel($a, $b, $c){

    $output = "<html>
                <head>
                  <title>
                    {$_SESSION['titlu_site']} - {$_SESSION['titlu_pagina']}
                  </title>
                  <link href='stil.css' rel='stylesheet'>
                </head>

                <body>

                <div align='center'>
                  <img src='img/titlu.jpg'>
                </div>";
    $output .= $a;
    $output .= "<div align='center'>
                <table width='90%' border=1 cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
                  <tr>
                    <td width='15%' valign='top' background='img/bgsumar2.gif'>
                      <br>";									
    
    $output .= $b.'<br>';
    $output .= $c.'<br>';
    $output .= "</td>
                    <td width='100%' height='100%' valign='top' bgcolor='#d4d4d4'>
                <br>
                <div align = center>
                <h1>
                 {$_SESSION['titlu_pagina']}
                </h1>
                </div>";

    return $output;          

	}
	
  protected function meniu() {
    $output = "
      <div align='center'>
        <table width='90%' border='0' background='img/bgsumar.gif' bgcolor='#EEF3F6'>
          <tr> 
            <td width=10%> 
                <div align='center'><a href='index.php'>Home</a></div>
            </td>
            <td width=10%> 
                <div align='center'><a href='index.php?pagina=cum_cumpar'>Cum cumpar</a></div>
            </td>
            <td width=10%>
              <div align='center'><a href='index.php?pagina=cautare1'>Cautare</a></div>
            </td>";
    if (isset($_SESSION['userlogat'])){
      $output .= "<td width=10%>
                    <div align='center'><a href='index.php?pagina=cos_temp_vizualizare'>Cos curent</a></div>
                  </td>";
      }
     $output .= "
            <td width=10%> 
              <div align='center'><a href='index.php?pagina=user_administrare'>Utilizator</a></div>
            </td>
            <td width=10%> 
                <div align='center'><a href='index.php?pagina=contact'>Contact</a></div>
            </td>
          </tr>
        </table>
    </div>";

    return $output;
  }

  
  protected function produs($row){ 
    
    $id_produs = $row['id_produs'];
    $nume_produs = $row['nume_produs'];
    $pret = $row['pret_ron'];
    $oferta = $row['oferta'];
    $descriere = $row['descriere'];
        
    $output = "<p align='center'>";
    $output .= "<a href='index.php?pagina=detalii_produs&id_produs=" . $id_produs ."'>" . ucfirst($nume_produs) . "</a><br>";

    $adresa_imagine = "imgproduse/" . $id_produs . ".jpg";
    if (file_exists ($adresa_imagine))
      $output .= "<a href='index.php?pagina=detalii_produs&id_produs=" . $id_produs . "'><img src=imgproduse/" . $id_produs . ".jpg width='100' height='100' border='0' ></a><br>";
    else
      $output .= "<a href='index.php?pagina=detalii_produs&id_produs=" . $id_produs . "'><img src=imgproduse/imagine_lipsa.gif width='100' height='100' border='0' alt='".$_SESSION['titlu_site']."'></a><br>";

    if ($oferta == 1){
      $output .= "Pret: <div class='blink'><span>{$pret} lei </span></div><br></p>";
    } else {
      $output .= "Pret: <p align='center' style='font-size:20px'>" . $pret . " lei </p><br>";
    }
    $output .= "<p align='center'>Descriere: $descriere</p>";

    return $output;
  }

  protected function tabel_produse($obiect){

    $afisari=0;
    $output = "<table width='100%' border=0>";
    $output .= "<tr>";
      while ($row = $obiect->fetch())
        {
          $output .= "<td width='25%' height='100'>".$this->produs($row)."</td>";
          $afisari++;
          if ($afisari%4==0)
           {
             $output .= "</tr>";
             $output .= "<tr>";
         }
        }
    $output .= "</tr>";
    $output .= "</table>";

    return $output;
    
  }

	protected function produse_la_promotie() {
		$output = '';
	  $nr_results = $this->results_produse_la_promotie->rowCount();
		
		if ($nr_results == 0)
			$output .=  "<p align='center'>Nu exista produse la promotie in acest moment.</p><br>";
		else
			{
        $output .= $this->tabel_produse($this->results_produse_la_promotie);
			}
		
		return $output;
  }		


  protected function right_panel_login() {
    
    if (!isset($_SESSION['userlogat']))
      {
        $output = "<table width='161' border=1 background='img/bgcaseta.jpg' cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
          <tr>
            <td>
              <form name='login' method='post' action='index.php?pagina=login'>
                <label for='username'>Utilizator:</label>
                <input type='text' name='username' id='username' class='txt'><br>

                <label for='password'>Parola:</label>
                <input type='password' name='password' class='txt'><br>

                <input type='submit' value='Login' class='buton'>
              </form>
          <p align='center'>
          <a href='index.php?pagina=user_creare1'>Creare cont nou</a></p><br>";

        
      }
    else 
      {
        $output = "<table width=161 height=85 border=1 background='img/bgcaseta.jpg' cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
            <tr>
              <td>";
      
        $output .= "<div align='center'>";
        $output .= "User logat: <b>" . $_SESSION['userlogat'] . "</b><br>";
        $output .= "<a href='index.php?pagina=cos_temp_vizualizare'>Vizualizare cos curent</a> <br>
                    <a href='index.php?pagina=user_administrare'>Utilizator</a> <br>
                    <a href='index.php?pagina=logout'>Logout</a></div>";
                }

    $output .=  "</td>
                </tr>
              </table>";
           
    return $output;

  }
  
  protected function cautare() {

    $output = "<table width='150' border=1 background='img/bgcaseta.jpg' cellpadding=2 cellspacing=0 bordercolor='#CCCCCC'>
      <tr>
        <td>
      <form name='frm_cautare' method='post' action='index.php?pagina=".'cautare2'."'>
      <br>
      <input type='text' name='produs_cautat' class='txt'><br>
      <input type='hidden' name='descriere_cautata' class='txt'><br>
      <input type='hidden' name='id_categ' class='txt' value='all'><br>
      <input type='submit' name='Submit' value='Cauta produs' class='buton'>
      </form>
        </td>
      </tr>
      </table>";

    return $output;
  }


  protected function reclame(){

    $output = "<a href='https://www.okazii.ro' target='_blank'>www.okazii.ro/</a><br><br>";
    $output .= "<a href='https://www.dedeman.ro' target='_blank'>www.dedeman.ro</a>";
    
    return $output;
  }

  protected function right_panel(){

    $output = "
            </td>
            <td width='15%' valign='top' background='img/bgsumar2.gif' align='center'>
        <br>";
    $output .= $this->cautare()."<br><br>";
    $output .= $this->right_panel_login()."<br><br>";
    $output .= $this->reclame();
    $output .= "
            </td>
          </tr>
        </table>
        </div>


        <div align='center'>
        <table background='img/bgsumar2.gif' border='0' width='90%' cellpadding='2' cellspacing='0' bgcolor='#EEF3F6'>
          <tr>
            <td>
              <p align='center'>
              &copy; - {$_SESSION['titlu_site']}
              </p>
            </td>
          </tr>
        </table>
        </div>
        </body>
        </html>";

        return $output;
  }


  public function final_output(){
    
    $output = $this->left_panel($this->meniu(),$this->sumar_categorii(),$this->cele_mai_vandute());
    $output .= $this->produse_la_promotie();
    $output .= $this->right_panel();
    
    echo $output;

  }

}