<?php
  session_start();
  echo "<link href='stil.css' rel='stylesheet'>";
  $_SESSION['titlu_site'] = "Magazin piese de schimb";
  $_SESSION['adresa_site'] = "http://www.facebook.com/magazin_auto";
  $_SESSION['adresa_site_www'] = "www.facebook.com/magazin_auto";
  $_SESSION['email_site'] = "ion.sorinalexandru@yahoo.com";
  $_SESSION['telefon']= "0721.420.657";
  $_SESSION['nelogat'] = "<p align='center'>Nu sunteti logat!</p>";
  $_SESSION['separator'] = " | ";
  $_SESSION['titlu_pagina'] = 'Home';
  $_SESSION['firma_nume'] = "SC AutoParts SRL Bucuresti";
  $_SESSION['firma_nrc'] = "J40/21321/1998";
  $_SESSION['firma_cui'] = "R645642";
  $_SESSION['firma_adresa'] = "Bucuresti, Sos. Mihai Bravu nr. 188";
  $_SESSION['firma_banca'] = "BCR - Sucursala Mihai Bravu";
  $_SESSION['firma_cont'] = "RO 43432432";


  require_once('Helpers/Autoload.php');
  \Helpers\Autoload::run();
  
  $controller_obj = new \Controllers\Dispatcher;

  
    