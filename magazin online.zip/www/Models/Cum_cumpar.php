<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Cum cumpar';

class Cum_cumpar extends Index{
	

}