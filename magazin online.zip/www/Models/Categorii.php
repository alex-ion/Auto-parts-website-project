<?php

namespace Models;
$_SESSION['titlu_pagina'] = '';

class Categorii extends Index{


	public function categorii($conexiune,$categorie) {

		try {
			
			if ($categorie!="")
				{
					$query = "SELECT * FROM produse JOIN categorii ON produse.id_categ = categorii.id_categ WHERE produse.id_categ=" . $categorie;
					$results = $conexiune->query($query);
				}

			return $results;
			
		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina Models'.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}


	public function nume_categorie($conexiune,$categorie){

		try {
			
			if ($categorie!="")
				{
					$query = "SELECT nume_categ FROM  categorii WHERE id_categ=" . $categorie;
					$results = $conexiune->query($query);
				}

			return $results;
			
		} catch (\PDOException $e) {
				
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}

}

