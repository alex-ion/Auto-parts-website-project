<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Detalii produs';

class Detalii_produs extends Index{


	public function produs($conexiune,$id_produs) {

		try {
			
			if ($id_produs!="")
				{
					$query = "SELECT * FROM produse WHERE id_produs={$id_produs}";
					$results = $conexiune->query($query);
				}

			return $results;
			
		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}

}

