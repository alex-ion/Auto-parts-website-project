<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Creare user';

class User_creare2 extends Index{


	public function user_creare2($conexiune,$parametrii) {

		$query_params = array(
			':username' => $parametrii['username'],
			':parola' => $parametrii['parola'],
			':nume' => $parametrii['nume'],
			':prenume' => $parametrii['prenume'],
			':adresa' => $parametrii['adresa'],
			':telefon' => $parametrii['telefon'],
			':email' => $parametrii['email'],
			':localitate' => $parametrii['localitate']
		);



		try {
				
			$query =  "SELECT * FROM useri WHERE username='{$query_params[':username']}'"; 
			$results = $conexiune->query($query);
			$nr_results1 = $results->rowCount();  
      if ($nr_results1 != 0)
        $output = "Exista deja in baza de date un utilizator cu acest nume!";
      else
        {			
					$query =  "SELECT * FROM useri WHERE email='{$query_params[':email']}'"; 
					$results = $conexiune->query($query);
					$nr_results2 = $results->rowCount();
					if ($nr_results2 != 0)
						$output = "Exista deja in baza de date un utilizator cu aceasta adresa de email!";
					else
						{	
						$query = "INSERT INTO useri VALUES (default, :username, :nume, :prenume, :adresa, :telefon, :email, :localitate , :parola)";
						$results = $conexiune->prepare($query);
						$results->execute($query_params);
						$nr_results3 = $results->rowCount();
						if ($nr_results3 === 0)
							$output = "A aparut o eroare la crearea contului!";
						else
							$output = "<b>Contul a fost creat!</b> Va multumim pentru inscrierea in baza noastra de date! <br>Numele dumneavoastra de utilizator este: <b>{$query_params[':username']}</b>";
        		}
				}

			return $output;

		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}

	}

}     