<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Creare user';

class User_creare1 extends Index{
	

}