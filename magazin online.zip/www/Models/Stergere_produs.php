<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Stergere produs';

class Stergere_produs extends Index{
	
public function stergere_produs($conexiune,$id_comanda){
  
  try {
			
    $query = "DELETE FROM cos_temporar WHERE id_comanda={$id_comanda}";
    $results = $conexiune->query($query);

    return $results;
    
  } catch (\PDOException $e) {
    
    $date_str = date('Y-m-d H:i:s');
    $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
    file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
    die('Database error!');
  }
}
}