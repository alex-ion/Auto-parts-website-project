<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Introducere in cos';

class Introducere_in_cos extends Index{
	

  public function introducere_in_cos($conexiune,$parametrii){

    if ($parametrii['cantitate']<=0 or !filter_var($parametrii['cantitate'],FILTER_VALIDATE_INT))
     $output = false;
    else
      {
        try
        {
          $query_params = array(
            ':id_user' => $_SESSION['id_user'],
            ':id_produs' => $parametrii['id_produs'],
            ':id_cantitate' => $parametrii['cantitate'],
            ':data' => date('Y-m-d')
          );

        
          $query = "INSERT INTO cos_temporar VALUES (DEFAULT, :id_user, :id_produs, :id_cantitate, :data)";
          $results = $conexiune->prepare($query);
          $results->execute($query_params);

          return $results;

        } catch (\PDOException $e) {
        
          $date_str = date('Y-m-d H:i:s');
          $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
          file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
          die('Database error!');
        }
	    }
    }

}