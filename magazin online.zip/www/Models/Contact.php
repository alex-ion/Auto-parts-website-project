<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Contact';

class Contact extends Index{
	

}