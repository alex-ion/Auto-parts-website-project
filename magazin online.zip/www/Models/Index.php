<?php

namespace Models;

class Index {

	private $db_obj;
		
	public function __construct($b) {
		
		$this->db_obj = $b;
		
	}
	

	public function produse_la_promotie() {

		try {
				
			$query = "SELECT * FROM produse WHERE oferta=1 ORDER BY nume_produs";
			$results = $this->db_obj->query($query);
			return $results;
			
		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}

	public function sumar_categorii() {

		try {
			$query = "SELECT * FROM categorii ORDER BY id_categ";
			$results = $this->db_obj->query($query);
			return $results;
			
		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}


	public function cele_mai_vandute() {

		try {
			
			$query = "SELECT istoric_comenzi.id_produs, nume_produs, SUM(cantitate) AS total_vanzari ";
			$query .= "FROM produse JOIN istoric_comenzi ";
			$query .= "ON produse.id_produs=istoric_comenzi.id_produs ";
			$query .= "GROUP BY istoric_comenzi.id_produs ";
			$query .= "ORDER BY total_vanzari DESC ";
			$query .= "LIMIT 0,10 ";
			$results = $this->db_obj->query($query);
			return $results;
			
		} catch (\PDOException $e) {
			
			$date_str = date('Y-m-d H:i:s');
			$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
			file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
			die('Database error!');
		}
	}

}