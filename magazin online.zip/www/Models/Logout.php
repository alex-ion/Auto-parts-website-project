<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Logout';

class Logout extends Index{
	

}