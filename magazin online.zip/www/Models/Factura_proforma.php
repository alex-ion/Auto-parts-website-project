<?php

namespace Models;
$_SESSION['titlu_pagina'] = '';

class Factura_proforma extends Index{
	


  public function date_user($conexiune){

    try
    {
      $query = "SELECT * FROM useri WHERE id_user={$_SESSION['id_user']}";
      $results = $conexiune->query($query);
      return $results;

    } catch (\PDOException $e) {
    
      $date_str = date('Y-m-d H:i:s');
      $error_msg = $date_str.': In pagina Models'.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
      file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
      die('Database error!');
    }
  }


  public function istoric_comenzi($conexiune){

    try
    {
      $query = "SELECT *, SUM(pret_ron*cantitate) as valoare, SUM(cantitate) as cantitate_produs FROM istoric_comenzi JOIN produse ON istoric_comenzi.id_produs=produse.id_produs WHERE id_user={$_SESSION['id_user']} GROUP BY produse.id_produs";
      $results = $conexiune->query($query);
      return $results;

    } catch (\PDOException $e) {
    
      $date_str = date('Y-m-d H:i:s');
      $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
      file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
      die('Database error!');
    }
  }

}



