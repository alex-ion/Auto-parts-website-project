<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Istoric comenzi';

class Istoric_comenzi extends Index{
	

  public function istoric_comenzi($conexiune){

    try
    {
      $query = "SELECT * FROM istoric_comenzi JOIN produse ON istoric_comenzi.id_produs=produse.id_produs  WHERE id_user='{$_SESSION['id_user']}'";
      $results = $conexiune->query($query);
      return $results;

    } catch (\PDOException $e) {
    
      $date_str = date('Y-m-d H:i:s');
      $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
      file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
      die('Database error!');
    }
    }

}