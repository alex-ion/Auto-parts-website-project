<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Modificare date utilizator';

class User_modificare1 extends Index{
  
  public function user_modificare1($conexiune) {

    try {
            
      $query = "SELECT * FROM useri WHERE id_user = {$_SESSION['id_user']} ";
      $results = $conexiune->query($query);
      return $results;

    } catch (\PDOException $e) {
      
      $date_str = date('Y-m-d H:i:s');
      $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
      file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
      die('Database error!');
    }
}
}