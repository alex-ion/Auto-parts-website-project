<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Plasare comanda';

class Plasare_comanda extends Index{

  public function plasare_comanda($conexiune){

    $comenzi_arr = array();

    try
    {
      $query = "SELECT * FROM cos_temporar WHERE id_user={$_SESSION['id_user']}";
      $results1 = $conexiune->query($query);
      while ($row = $results1->fetch())
      {
        $comanda = array(
        'id_comanda' => $row['id_comanda'],
        'id_user' => $row['id_user'],
        'id_produs' => $row['id_produs'],
        'cantitate' => $row['cantitate'],
        'data_comanda' => $row['data_comanda']);
        $comenzi_arr[] = $comanda;
      }
      
      foreach($comenzi_arr as $value){
        $query = "INSERT INTO istoric_comenzi VALUES (default, {$value['id_user']}, {$value['id_produs']}, '{$value['cantitate']}', '{$value['data_comanda']}')";
        $results2 = $conexiune->query($query);

      }

      foreach($comenzi_arr as $value){
        $query = "DELETE FROM cos_temporar WHERE id_comanda={$value['id_comanda']}";
        $results3 = $conexiune->query($query);
      }
      
      return TRUE;

    } catch (\PDOException $e) {
    
      $date_str = date('Y-m-d H:i:s');
      $error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
      file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
      die('Database error!');
    }
  
    }

}




