<?php

namespace Models;
$_SESSION['titlu_pagina'] = 'Cautare';

class Cautare2 extends Index{

	static function gasire_produs($conexiune, $parametrii) {
		
		$query_params = array(
			':produs_cautat' => '%'.$parametrii['produs_cautat'].'%',
			':id_categ' => $parametrii['id_categ']
		);

		if (isset($parametrii['produs_cautat'])){
			try {
					
				$query = "SELECT * FROM produse JOIN categorii ON produse.id_categ=categorii.id_categ WHERE nume_produs LIKE :produs_cautat";
				if ($query_params[':id_categ'] != 'all')
					$query .= " AND categorii.id_categ = :id_categ";
				else
					$query .= " AND :id_categ = :id_categ";
				$query .= " ORDER BY produse.nume_produs";
				$results = $conexiune->prepare($query);
				$results->execute($query_params);
				return $results;

			} catch (\PDOException $e) {
				
				$date_str = date('Y-m-d H:i:s');
				$error_msg = $date_str.': In pagina '.__NAMESPACE__.$_SERVER['PHP_SELF'].' <---> '.$e->getMessage()."\r\n";
				file_put_contents('db_errors.log', $error_msg, FILE_APPEND);
				die('Database error!');
			}
		}
	}

}